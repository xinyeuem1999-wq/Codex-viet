.class public Lapk/tool/patcher/Premium;
.super Ljava/lang/Object;
.source "Premium"

.method public static Premium()Z
    .locals 1
    const/4 v0, 0x1
    return v0
.end method
