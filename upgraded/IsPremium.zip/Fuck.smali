.class public Lcom/fuck/Fuck;
.super Ljava/lang/Object;
.source "Fuck.java"


# static fields
.field private static BUTTON_TEXT:Ljava/lang/String;

.field private static MESSAGE:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .prologue
    .line 14
    const-string v0, "\u0417\u0430\u043a\u0440\u044b\u0442\u044c\u0020\u043d\u0430\u0432\u0441\u0435\u0433\u0434\u0430\u002e"

    sput-object v0, Lcom/fuck/Fuck;->BUTTON_TEXT:Ljava/lang/String;

    .line 15
    const-string v0, "Help for SaWSeM"

    sput-object v0, Lcom/fuck/Fuck;->MESSAGE:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .prologue
    .line 13
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static ModInfo(Landroid/app/Activity;)V
    .locals 9
    .param p0, "context"    # Landroid/app/Activity;

    .prologue
    const/4 v8, 0x1

    const/4 v7, 0x0

    .line 18
    const-string v5, "ModInfo"

    invoke-virtual {p0, v5, v7}, Landroid/app/Activity;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v5

    const-string v6, "by SaWSeM"

    invoke-interface {v5, v6, v8}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v5

    if-eqz v5, :cond_0

    .line 19
    sget-object v5, Lcom/fuck/Fuck;->MESSAGE:Ljava/lang/String;

    invoke-static {p0, v5, v8}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v5

    invoke-virtual {v5}, Landroid/widget/Toast;->show()V

    .line 20
    const-string v5, "ModInfo"

    invoke-virtual {p0, v5, v7}, Landroid/app/Activity;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v5

    invoke-interface {v5}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v5

    const-string v6, "by SaWSeM"

    invoke-interface {v5, v6, v7}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v5

    invoke-interface {v5}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 21
    const-string v2, "\u041f\u043e\u0436\u0435\u0440\u0442\u0432\u043e\u0432\u0430\u0442\u044c\u0020\u043d\u0430\u0020\u0022\u0440\u0430\u0437\u0433\u043e\u043d\u0022\u0020\u041f\u041a\u003a<br/><br>QIWI > +79042585040<br/><br>Yandex Деньги  > 410013858440166<br/><br>\u0422\u0440\u0435\u0431\u0443\u0435\u043c\u0430\u044f\u0020\u0441\u0443\u043c\u043c\u0430\u0020\u0035\u004b<br/><br>"

    .line 22
    .local v2, "message":Ljava/lang/String;
    invoke-static {v2}, Landroid/text/Html;->fromHtml(Ljava/lang/String;)Landroid/text/Spanned;

    move-result-object v4

    .line 23
    .local v4, "myMessage":Landroid/text/Spanned;
    new-instance v0, Landroid/app/AlertDialog$Builder;

    invoke-direct {v0, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 24
    .local v0, "ADB":Landroid/app/AlertDialog$Builder;
    sget-object v5, Lcom/fuck/Fuck;->MESSAGE:Ljava/lang/String;

    invoke-virtual {v0, v5}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 25
    invoke-virtual {v0, v4}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 26
    invoke-virtual {v0, v7}, Landroid/app/AlertDialog$Builder;->setCancelable(Z)Landroid/app/AlertDialog$Builder;

    .line 27
    sget-object v5, Lcom/fuck/Fuck;->BUTTON_TEXT:Ljava/lang/String;

    const/4 v6, 0x0

    invoke-virtual {v0, v5, v6}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 28
    const-string v5, "Пожертвовать"

    new-instance v6, Lcom/fuck/Fuck1;

    invoke-direct {v6, p0}, Lcom/fuck/Fuck1;-><init>(Landroid/app/Activity;)V

    invoke-virtual {v0, v5, v6}, Landroid/app/AlertDialog$Builder;->setNeutralButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 35
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object v1

    .line 36
    .local v1, "alert":Landroid/app/AlertDialog;
    invoke-virtual {v1}, Landroid/app/AlertDialog;->show()V

    .line 37
    const v5, 0x102000b

    invoke-virtual {v1, v5}, Landroid/app/AlertDialog;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/TextView;

    .line 38
    .local v3, "msgText":Landroid/widget/TextView;
    invoke-static {}, Landroid/text/method/LinkMovementMethod;->getInstance()Landroid/text/method/MovementMethod;

    move-result-object v5

    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setMovementMethod(Landroid/text/method/MovementMethod;)V

    .line 40
    .end local v0    # "ADB":Landroid/app/AlertDialog$Builder;
    .end local v1    # "alert":Landroid/app/AlertDialog;
    .end local v2    # "message":Ljava/lang/String;
    .end local v3    # "msgText":Landroid/widget/TextView;
    .end local v4    # "myMessage":Landroid/text/Spanned;
    :cond_0
    return-void
.end method
