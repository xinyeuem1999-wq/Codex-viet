.class public Lpatchx/DataGuard;
.super Ljava/lang/Object;

.field public static CONTROL_ENABLED:Z

.method static constructor <clinit>()V
    .registers 1

    const/4 v0, 0x0
    sput-boolean v0, Lpatchx/DataGuard;->CONTROL_ENABLED:Z

    return-void
.end method

.method public static onCreate()V
    .registers 2

    const-string v0, "patchx-remote-control"
    const-string v1, "DataGuard hook installed"
    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method

.method public static onEvent(Ljava/lang/String;Ljava/lang/String;)V
    .registers 4

    const-string v0, "patchx-remote-control"
    invoke-static {v0, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method

.method public static onSendHit(Ljava/lang/String;)V
    .registers 3

    const-string v0, "patchx-remote-control"
    invoke-static {v0, p0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method
